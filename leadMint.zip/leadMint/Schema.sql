CREATE DATABASE chat_room_system;

USE chat_room_system;

CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId VARCHAR(255) NOT NULL,
  deviceId VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  availCoins INT NOT NULL DEFAULT 0,
  isPrimeMember BOOLEAN NOT NULL DEFAULT FALSE,
  password VARCHAR(255) NOT NULL
);

CREATE TABLE chat_rooms (
  id INT PRIMARY KEY AUTO_INCREMENT,
  creatorId INT NOT NULL,
  roomName VARCHAR(255) NOT NULL,
  roomPassword VARCHAR(255) NOT NULL,
  maxCapacity INT NOT NULL DEFAULT 6,
  FOREIGN KEY (creatorId) REFERENCES users(id)
);

CREATE TABLE chat_room_participants (
  id INT PRIMARY KEY AUTO_INCREMENT,
  chatRoomId INT NOT NULL,
  userId INT NOT NULL,
  FOREIGN KEY (chatRoomId) REFERENCES chat_rooms(id),
  FOREIGN KEY (userId) REFERENCES users(id)
);

CREATE TABLE messages (
  id INT PRIMARY KEY AUTO_INCREMENT,
  chatRoomId INT NOT NULL,
  userId INT NOT NULL,
  message TEXT NOT NULL,
  createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (chatRoomId) REFERENCES chat_rooms(id),
  FOREIGN KEY (userId) REFERENCES users(id)
);

CREATE TABLE friend_requests (
  id INT PRIMARY KEY AUTO_INCREMENT,
  senderId INT NOT NULL,
  receiverId INT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  FOREIGN KEY (senderId) REFERENCES users(id),
  FOREIGN KEY (receiverId) REFERENCES users(id)
);