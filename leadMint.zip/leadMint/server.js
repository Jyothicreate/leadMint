const express = require('express');
const app = express();
app.use(express.json());
const mysql = require('mysql2/promise');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const WebSocket = require('ws');

// MySQL Database Configuration
const db = mysql.createPool({
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: '060298@Jyo',
  database: 'chat_room_system'
});

// Database Connection Check
db.getConnection().then((connection) => {
  connection.query('SELECT 1').then(() => {
    console.log('Connected to database');
    connection.release();
  }).catch((err) => {
    console.error('Error connecting to database:', err);
    connection.release();
  });
}).catch((err) => {
  console.error('Error getting connection from pool:', err);
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Middleware for authentication
function authenticateUser(req, res, next) {
  const token = req.headers.authorization.split(' ')[1];
  if (!token) {
    res.status(401).send({ message: 'Unauthorized' });
    return;
  }
  try {
    const decoded = jwt.verify(token, 'secretkey');
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).send({ message: 'Unauthorized' });
  }
}

// Middleware for authentication of prime members
function authenticatePrimeMember(req, res, next) {
  authenticateUser(req, res, () => {
    if (req.user.isPrimeMember) {
      next();
    } else {
      res.status(403).send({ message: 'Forbidden: Only prime members can create chat rooms' });
    }
  });
}

// Middleware for authentication of non-prime members
function authenticateNonPrimeMember(req, res, next) {
  authenticateUser(req, res, () => {
    if (!req.user.isPrimeMember && req.user.freeRoomCount > 0) {
      req.user.freeRoomCount--;
      next();
    } else if (!req.user.isPrimeMember && req.user.freeRoomCount === 0) {
      res.status(403).send({ message: 'Forbidden: Non-prime members can join only one room for free' });
    } else {
      res.status(403).send({ message: 'Forbidden: Only prime members can create chat rooms' });
    }
  });
}

// Endpoint for user registration
app.post('/api/register', (req, res) => {
  console.log('Received request body:', req.body);
  const { userId, deviceId, name, phone, password } = req.body;
  console.log('Received request:', { userId, deviceId, name, phone, password });
  if (!userId || !deviceId || !name || !phone || !password) {
    res.status(400).send({ message: 'Missing required fields' });
    return;
  }
  bcrypt.genSalt(10, (err, salt) => {
    if (err) {
      console.error('Error generating salt:', err);
      res.status(500).send({ message: 'Error registering user' });
      return;
    }
    bcrypt.hash(password, salt, (err, hash) => {
      if (err) {
        console.error('Error hashing password:', err);
        res.status(500).send({ message: 'Error registering user' });
        return;
      }
      db.query(`INSERT INTO users (userId, deviceId, name, phone, passwordHash) VALUES (?,?,?,?,?)`,
        [userId, deviceId, name, phone, hash], // Inserting the hashed password
        (err, results) => {
          if (err) {
            console.error('Error inserting user data:', err);
            res.status(500).send({ message: 'Error registering user' });
            return;
          }
          res.send({ message: 'User registered successfully' });
        }
      );
    });
  });
});


// Endpoint for user login
app.post('/api/login', (req, res) => {
  const { userId, password } = req.body;
  db.query(`SELECT * FROM users WHERE userId =?`, [userId], (err, results) => {
    if (err ||!results.length) {
      res.status(401).send({ message: 'Invalid credentials' });
      return;
    }
    const user = results[0];
    bcrypt.compare(password, user.passwordHash, (err, isMatch) => {
      if (err ||!isMatch) {
        res.status(401).send({ message: 'Invalid credentials' });
        return;
      }
      const token = jwt.sign({ userId: user.userId }, 'secretkey', { expiresIn: '1h' });
      res.send({ token });
    });
  });
});

// Endpoint for chat room creation
app.post('/api/chatrooms', authenticatePrimeMember, (req, res) => {
  const { roomName, roomPassword } = req.body;
  db.query(`INSERT INTO chat_rooms (creatorId, roomName, roomPassword) VALUES (?,?,?)`,
    [req.user.userId, roomName, roomPassword],
    (err, results) => {
      if (err) {
        res.status(500).send({ message: 'Error creating chat room' });
        return;
      }
      res.send({ message: 'Chat room created successfully' });
    }
  );
});

// Endpoint for joining a room as a non-prime member
app.post('/api/joinroom', authenticateNonPrimeMember, (req, res) => {
  const { roomId } = req.body;
  db.query(`SELECT * FROM chat_rooms WHERE roomId =?`, [roomId], (err, results) => {
    if (err ||!results.length) {
      res.status(404).send({ message: 'Chat room not found' });
      return;
    }
    const room = results[0];
    db.query(`SELECT COUNT(*) as participantCount FROM room_participants WHERE roomId =?`, [roomId], (err, results) => {
      if (err) {
        res.status(500).send({ message: 'Error joining chat room' });
        return;
      }
      if (results[0].participantCount >= room.maxCapacity) {
        res.status(403).send({ message: 'Chat room is full' });
        return;
      }
      db.query(`INSERT INTO room_participants (roomId, userId) VALUES (?,?)`, [roomId, req.user.userId], (err, results) => {
        if (err) {
          res.status(500).send({ message: 'Error joining chat room' });
          return;
        }
        res.send({ message: 'Joined chat room successfully' });
      });
    });
  });
});

// WebSocket Configuration
const wss = new WebSocket.Server({ noServer: true });

wss.on('connection', (ws) => {
  ws.on('message', (message) => {
    const parsedMessage = JSON.parse(message);
    const { roomId, userId, messageText } = parsedMessage;
    db.query(`INSERT INTO messages (roomId, userId, messageText) VALUES (?,?,?)`, [roomId, userId, messageText], (err, results) => {
      if (err) {
        console.error('Error saving message:', err);
        return;
      }
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN && client !== ws) {
          client.send(JSON.stringify(parsedMessage));
        }
      });
    });
  });
});

// Endpoint for viewing user profile
app.get('/api/profile/:userId', authenticateUser, (req, res) => {
  db.query(`SELECT * FROM users WHERE userId =?`, [req.params.userId], (err, results) => {
    if (err) {
      res.status(500).send({ message: 'Error fetching profile' });
      return;
    }
    if (results.length) {
      res.send(results[0]);
    } else {
      res.status(404).send({ message: 'Profile not found' });
    }
  });
});

// Endpoint for sending friend requests
app.post('/api/friend-requests', authenticateUser, (req, res) => {
  const { receiverId } = req.body;
  db.query(`SELECT * FROM users WHERE userId =?`, [receiverId], (err, results) => {
    if (err) {
      res.status(500).send({ message: 'Error sending friend request' });
      return;
    }
    if (results.length) {
      db.query(`INSERT INTO friend_requests (senderId, receiverId) VALUES (?,?)`, [req.user.userId, receiverId], (err, results) => {
        if (err) {
          res.status(500).send({ message: 'Error sending friend request' });
          return;
        }
        res.send({ message: 'Friend request sent successfully' });
      });
    } else {
      res.status(404).send({ message: 'Receiver not found' });
    }
  });
});
